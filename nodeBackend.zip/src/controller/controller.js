const userModel = require("../model/model");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");

exports.postdata = async (req, res) => {
  const file = req.body.image;
  try {
    const exitingUser = await userModel.findOne({ email: req.body.email });
    const exitingUsers = await userModel.findOne({ phone: req.body.phone });
    if (exitingUser) {
      res.status(405).json("email is already existed");
    } else if (exitingUsers) {
      res.status(405).json(" phone is already existed");
    } else if (req.body.phone > 9999999999 || req.body.phone < 1000000000) {
      res.status(405).json(" phone is invalid");
    } else if (!req.body.image) {
      res.status(405).json(" provide image");
    } else {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
      }
      const hasspass = await bcrypt.hash(req.body.password, 10);
      const User = new userModel({
        name: req.body.name,
        phone: req.body.phone,
        email: req.body.email,
        password: hasspass,
        image: file,
      });
      const result = await User.save();
      if (result._id) {
        const token = jwt.sign({ id: result._id }, "secretKey", {
          expiresIn: "24hr",
        });
        res.status(200).json({ id: result._id, token: token });
      }
    }
  } catch (error) {
    res.status(400).json({ msg: error });
    console.log("error", error);
  }
};

exports.login = async (req, res) => {
  try {
    if (!req.body.email || !req.body.password) {
      res.send("input should not empty");
    }
    const user = await userModel.findOne({ email: req.body.email });
    if (!user) {
      res.send("email is not registered");
    } else {
      const pass = bcrypt.compare(
        req.body.password,
        user.password,
        (err, result) => {
          if (result == true) {
            const token = jwt.sign({ id: user.id }, "secretKey", {
              expiresIn: "24hr",
            });
            res.send({ id: user.id, token: token });
          } else {
            res.send("login failed");
          }
        }
      );
    }
  } catch (error) {
    res.send(error);
  }
};

exports.fetchData = async (req, res) => {
  let { page, limit, sort, asc } = req.query;
  try {
    if (!sort) {
      sort = "phone";
    }
    if (!asc) asc = -1;
    if (!page) page = 1;
    if (!limit) limit = 10;
    const skip = (page - 1) * limit;
    const users = await userModel
      .find()
      .skip(skip)
      .limit(limit)
      .sort({ [sort]: asc });
    const count = users.length;
    res.send({ users, count });
  } catch (error) {
    res.send(error);
  }
};

exports.nameSearch = async (req, res) => {
  try {
    const { name } = req.body;
    const query = { name: new RegExp(name, "i") };
    const user = await userModel.find(query);
    res.send(user);
  } catch (error) {
    // handle error
    res.send(error.message)
  }
};

exports.sortName = async (req, res) => {
  let { page, limit, sort, asc } = req.query;
  try {
    if (!sort) {
      sort = "phone";
    }
    if (!asc) asc = -1;
    if (!page) page = 1;
    if (!limit) limit = 10;
    const skip = (page - 1) * limit;
    const users = await userModel
      .find()
      .skip(skip)
      .limit(limit)
      .sort({ name: asc });
    const count = users.length;
    res.send({ users, count });
  } catch (error) {
    res.send(error);
  }
};

exports.sortPhone = async (req, res) => {
  let { page, limit, sort, asc } = req.query;
  try {
    if (!sort) {
      sort = "phone";
    }
    if (!asc) asc = -1;
    if (!page) page = 1;
    if (!limit) limit = 10;
    const skip = (page - 1) * limit;
    const users = await userModel
      .find()
      .skip(skip)
      .limit(limit)
      .sort({ [sort]: asc });
    const count = users.length;
    res.send({ users, count });
  } catch (error) {
    res.send(error);
  }
};

exports.sortEmail = async (req, res) => {
  let { page, limit, sort, asc } = req.query;
  try {
    if (!sort) {
      sort = "phone";
    }
    if (!asc) asc = -1;
    if (!page) page = 1;
    if (!limit) limit = 10;
    const skip = (page - 1) * limit;
    const users = await userModel
      .find()
      .skip(skip)
      .limit(limit)
      .sort({ email: asc });
    const count = users.length;
    res.send({ users, count });
  } catch (error) {
    res.send(error);
  }
};

exports.singleUser = async (req, res) => {
    try {
    const user = await userModel
      .findById({ _id: req.params.id },{password:0})
    if (!user) {
      res.send("plzz provide right id");
    }
    res.send(user);
  } catch (error) {
    if(error){
     res.send("something went wrong")
    }
  }
   
};

exports.Update =async(req,res)=>{
  try {
    const user= await userModel.findById(req.params.id)
    if(!user){
      res.send("plzz provide right id")
    }
    console.log(req.body);
    const result= await userModel.findByIdAndUpdate(req.params.id,{
      name: req.body.name,
      phone: req.body.phone,
      email: req.body.email},{
      new:true,
      runValidator:true
    })
    res.send(result)
  } catch (error) {
    res.send(error.message)
    
  }
}