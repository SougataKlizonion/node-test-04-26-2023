const express =require("express");
const router  =express.Router();
const controller =require("../controller/controller")
const auth = require("../middleware/auth")
const { body, validationResult } = require('express-validator');

router.post("/data",
[body('email',"plz provide right email id").isEmail(),
body('password',"password is too week").isLength({ min: 5 }),
body('name',"provide a name").isLength({ min: 1 }),
body('phone',"plzz provide right phone number").isLength({ min: 10 ,max: 10})],controller.postdata);
router.post("/login",controller.login)
router.get('/data',auth,controller.fetchData)
router.post('/search',controller.nameSearch)
router.get('/user/:id',controller.singleUser)
router.get('/name',controller.sortName)
router.get('/phone',controller.sortPhone)
router.get('/email',controller.sortEmail)
router.put('/edit/:id',controller.Update)



module.exports=router